# arras
Arras is a framework for interactive distributed computation

- **core** contains the C++ APIs and implementation for the core of Arras
- **distributed** contains services required to use Arras across multiple machines
